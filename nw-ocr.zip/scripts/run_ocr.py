#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OCR 技能命令行入口。

stdout 只输出最终结果（默认 Markdown 文本；--json 输出结构化 JSON），过程日志走 stderr。
退出码：0 成功，1 失败（失败时 stdout 输出 {"status": "error", "error": ...}）。
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from ocr_api import OCRClient


def main() -> int:
    parser = argparse.ArgumentParser(description="南网推理平台 OCR：识别图片/PDF 为 Markdown")
    parser.add_argument("--file", required=True, help="文件路径（沙箱内绝对路径）、文件 URL 或 Base64 字符串")
    parser.add_argument("--input-type", default="path", choices=["path", "url", "base64"], help="输入类型，默认 path")
    parser.add_argument("--file-type", type=int, default=None, choices=[0, 1], help="0=PDF 1=图像，不传自动推断")
    parser.add_argument("--timeout", type=int, default=120, help="超时秒数，默认 120")
    parser.add_argument("--no-orient", action="store_true", help="关闭图片方向矫正")
    parser.add_argument("--no-unwarp", action="store_true", help="关闭扭曲/倾斜矫正")
    parser.add_argument("--no-layout", action="store_true", help="关闭版面检测（VL 模式，可配合 --prompt-label）")
    parser.add_argument("--prompt-label", default=None, choices=["ocr", "formula", "table", "chart"],
                        help="VL 模式任务类型，仅 --no-layout 时生效")
    parser.add_argument("--json", action="store_true", help="输出结构化 JSON 而非纯 Markdown")
    args = parser.parse_args()

    try:
        client = OCRClient()
        extra = {}
        if args.prompt_label:
            extra["promptLabel"] = args.prompt_label
        result = client.recognize(
            args.file,
            file_type=args.file_type,
            input_type=args.input_type,
            use_doc_orientation=not args.no_orient,
            use_doc_unwarping=not args.no_unwarp,
            use_layout_detection=not args.no_layout,
            timeout=args.timeout,
            **extra,
        )
        markdown = OCRClient.extract_markdown(result)
        if not markdown.strip():
            print(json.dumps({"status": "error", "error": "识别结果为空：文件可能无文本或不是有效图片/PDF"},
                             ensure_ascii=False))
            return 1
        if args.json:
            print(json.dumps({
                "status": "ok",
                "pages": OCRClient.page_count(result),
                "markdown": markdown,
            }, ensure_ascii=False))
        else:
            print(markdown)
        return 0
    except Exception as e:  # noqa: BLE001 统一转成结构化错误给模型
        print(json.dumps({"status": "error", "error": str(e)}, ensure_ascii=False))
        return 1


if __name__ == "__main__":
    sys.exit(main())
