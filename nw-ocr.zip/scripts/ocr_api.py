#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""南网推理平台 OCR 客户端（HMAC-SHA256 签名认证）。

凭证内置默认值（随技能包分发），可通过环境变量覆盖：
- OCR_CUSTOMER_CODE  客户系统编码
- OCR_SECRET_KEY     认证密钥
- OCR_COMPONENT_CODE 组件编码（默认 04101936）
- OCR_GATEWAY_URL    网关地址（默认南网推理平台地址）
"""
import base64
import hmac
import json
import os

import requests
import urllib3
from hashlib import sha256
from datetime import datetime, timezone
from typing import Any, Dict, Optional, Union

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

DEFAULT_CUSTOMER_CODE = "1003500011"
DEFAULT_SECRET_KEY = "87c851dea66c4f0abd9f8aff3a1220d8"
DEFAULT_COMPONENT_CODE = "04101936"
DEFAULT_GATEWAY_URL = "https://10.10.65.213:18300/ai-gateway/predict"


class OCRClient:
    """推理平台 OCR 接口客户端"""

    def __init__(
        self,
        customer_code: Optional[str] = None,
        secret_key: Optional[str] = None,
        component_code: Optional[str] = None,
        gateway_url: Optional[str] = None,
    ):
        self.customer_code = customer_code or os.environ.get("OCR_CUSTOMER_CODE", DEFAULT_CUSTOMER_CODE)
        self.secret_key = secret_key or os.environ.get("OCR_SECRET_KEY", DEFAULT_SECRET_KEY)
        self.component_code = component_code or os.environ.get("OCR_COMPONENT_CODE", DEFAULT_COMPONENT_CODE)
        self.gateway_url = gateway_url or os.environ.get("OCR_GATEWAY_URL", DEFAULT_GATEWAY_URL)
        if not self.customer_code or not self.secret_key:
            raise ValueError("缺少凭证：请配置技能环境变量 OCR_CUSTOMER_CODE / OCR_SECRET_KEY")

    def _get_sign(self, data: str, key: str) -> str:
        return base64.b64encode(
            hmac.new(key.encode("utf-8"), data.encode("utf-8"), digestmod=sha256).digest()
        ).decode("utf-8")

    def _get_auth_info(self) -> tuple:
        """生成认证信息 (x_date, authorization)"""
        x_date = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S GMT")
        sign = self._get_sign("x-date: " + x_date, self.secret_key)
        auth = (
            f'hmac username="{self.customer_code}",'
            f'algorithm="hmac-sha256",'
            f'headers="x-date",'
            f'signature="{sign}"'
        )
        return x_date, auth

    def recognize(
        self,
        file_input: str,
        file_type: Optional[int] = None,
        input_type: str = "path",
        use_doc_orientation: bool = True,
        use_doc_unwarping: bool = True,
        use_layout_detection: bool = True,
        prettify_markdown: bool = True,
        timeout: int = 120,
        **kwargs,
    ) -> Dict[str, Any]:
        """
        调用 OCR 接口识别图片/PDF。

        file_input: Base64 字符串、文件路径或文件 URL（由 input_type 决定）
        file_type:  0=PDF，1=图像，None=自动推断
        """
        if input_type == "path":
            if not os.path.exists(file_input):
                raise ValueError(f"文件不存在: {file_input}")
            with open(file_input, "rb") as f:
                file_param = base64.b64encode(f.read()).decode("utf-8")
        elif input_type in ("url", "base64"):
            file_param = file_input
        else:
            raise ValueError(f"不支持的 input_type: {input_type}")

        if file_type is None:
            file_type = 0 if (input_type == "url" and file_param.lower().endswith(".pdf")) else 1

        payload = {
            "componentCode": self.component_code,
            "file": file_param,
            "fileType": file_type,
            "useDocOrientationClassify": use_doc_orientation,
            "useDocUnwarping": use_doc_unwarping,
            "useLayoutDetection": use_layout_detection,
            "prettifyMarkdown": prettify_markdown,
        }
        payload.update(kwargs)

        x_date, auth = self._get_auth_info()
        resp = requests.post(
            self.gateway_url,
            headers={"x-date": x_date, "Content-Type": "application/json", "authorization": auth},
            data=json.dumps(payload),
            verify=False,
            timeout=timeout,
            proxies={"http": None, "https": None},
        )
        try:
            result = resp.json()
        except Exception:
            raise Exception(f"OCR 网关返回非 JSON（HTTP {resp.status_code}）：{resp.text[:300]}")
        if resp.status_code != 200:
            raise Exception(f"OCR 调用失败 (HTTP {resp.status_code})：{result.get('errorMsg', result.get('message', '未知错误'))}")
        return result

    @staticmethod
    def extract_markdown(result: Dict[str, Any]) -> str:
        """从响应提取 Markdown 文本（多页拼接）"""
        md_texts = []
        try:
            for page in result["result"]["layoutParsingResults"]:
                text = (page.get("markdown") or {}).get("text")
                if text:
                    md_texts.append(text)
        except (KeyError, TypeError):
            pass
        return "\n\n".join(md_texts)

    @staticmethod
    def page_count(result: Dict[str, Any]) -> int:
        try:
            return len(result["result"]["layoutParsingResults"])
        except (KeyError, TypeError):
            return 0
