---
name: nw-ocr
description: 南网推理平台 OCR 文字识别。把图片或 PDF（扫描件、拍照件、截图、票据、证件、文档照片）识别为 Markdown 文本，支持方向矫正、版面分析、公式/表格/图表识别。触发词：OCR/识别图片/图片文字/扫描件/图片转文字/识别PDF/看图/提取图片内容。只读技能，无任何写入操作。
---

# 南网 OCR 文字识别

通过南网推理平台 OCR 接口，把图片/PDF 识别成 Markdown 文本。所有调用逻辑固定在 `scripts/run_ocr.py`，按参数执行即可。

## 环境变量（已内置默认值，无需配置即可用）

凭证已内置于技能包（`scripts/ocr_api.py` 默认值），开箱即用。如需更换，在技能市场配置以下变量覆盖：

| 变量 | 说明 |
|---|---|
| `OCR_CUSTOMER_CODE` | 客户系统编码 |
| `OCR_SECRET_KEY` | 认证密钥 |

可选：`OCR_GATEWAY_URL`（网关地址）、`OCR_COMPONENT_CODE`（组件编码，默认 04101936）。

## 工作流程

1. **定位输入文件**。用户上传的文件在 `/workspace/user/files/` 下（用 `ls` 或 `glob` 确认实际路径）；用户给的是文件 URL 则直接用 `--input-type url`。
2. **执行识别**（只读操作，直接运行，无需确认）：

```bash
python skills/nw-ocr/scripts/run_ocr.py --file /workspace/user/files/xxx.png
```

3. **返回结果**：stdout 即 Markdown 文本，直接整理后答复用户；加 `--json` 可拿到 `{"status","pages","markdown"}` 结构化输出。

## 参数速查

| 参数 | 说明 |
|---|---|
| `--file` | 文件路径 / URL / Base64（必填） |
| `--input-type` | `path`（默认）/ `url` / `base64` |
| `--file-type` | `0`=PDF `1`=图像，不传自动推断 |
| `--timeout` | 超时秒数，默认 120（大 PDF 可调大） |
| `--no-orient` / `--no-unwarp` | 关闭方向矫正 / 扭曲矫正 |
| `--no-layout` + `--prompt-label` | VL 模式：`ocr`/`formula`（公式）/`table`（表格）/`chart`（图表） |

## 使用示例

识别用户上传的图片：

```bash
python skills/nw-ocr/scripts/run_ocr.py --file /workspace/user/files/发票照片.png
```

识别 URL 指向的 PDF（第 100 页以内）：

```bash
python skills/nw-ocr/scripts/run_ocr.py --file "https://xxx/报告.pdf" --input-type url
```

只识别表格（VL 模式）：

```bash
python skills/nw-ocr/scripts/run_ocr.py --file /workspace/user/files/报表.png --no-layout --prompt-label table
```

## 输出与错误约定

- 成功：stdout 输出 Markdown 文本（默认）或 JSON（`--json`），退出码 0
- 失败：stdout 输出 `{"status": "error", "error": "原因"}`，退出码 1——把 error 内容如实告知用户；"缺少凭证"提示去技能市场配置环境变量；"识别结果为空"提示文件可能无文本层
- 过程日志在 stderr，可忽略

## 安全要求

不要打印 `OCR_SECRET_KEY` 的值或签名串。不要把识别出的敏感证件信息（身份证号等）原样大段复述，按用户问题摘取必要内容。
